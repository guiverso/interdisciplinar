const registerBtn = document.querySelector('#registerBtn');
const usernameInput = document.querySelector('#Username');
const passwordInput = document.querySelector('#Password');

registerBtn.addEventListener('click', async () => {
    const response = await fetch('/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: usernameInput.value,
            password: passwordInput.value
        })
    });

    if (response.ok) {
        // Registration successful
        window.location.href = '/auth';
    } else {
        // Registration failed
        alert('Registration failed. Please try again with different credentials.');
    }
    
});