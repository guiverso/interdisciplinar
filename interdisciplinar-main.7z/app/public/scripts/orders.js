async function getAllOrders() {
    try {
        const response = await fetch('/orders/getOrders', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const orders = await response.json();
        let pedidos = document.querySelector('#pedidos-tbody');
        pedidos.innerHTML = '';
        orders.forEach(order => {
            let row = document.createElement('tr');
            row.innerHTML = `
              <td>${order.id}</td>
              <td>${order.items.map(item => `${item.name} × ${item.quantity}`).join(', ')}</td>
              <td>${order.total.toFixed(2)}</td>
              <td><span class="status ${order.status}">${order.status}</span></td>
              <td>
                <button class="btn status-btn" onclick="changeStatus(this, 'fazendo')">Fazendo</button>
                <button class="btn status-btn" onclick="changeStatus(this, 'pronto')">Pronto</button>
                <button class="btn delete-btn" onclick="deletePedido(this)">Cancelar</button>
              </td>
            `;
            pedidos.appendChild(row);
        });
    } catch (error) {
        console.log(error);
    }
}

async function getItemsForOrder(orderId) {
    try {
        const response = await fetch(`/menu/getItems`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const items = await response.json();
        console.log(items);
        const itensdiv = document.getElementById('itensSelect');
        itensdiv.innerHTML = '';
        items.forEach(item => {
            const div = document.createElement('div');
            div.classList.add('form-check');
            div.innerHTML = `
                <span class="input-group-text" id="basic-addon1">${item.nome}</span>
                <input type="number" class="form-control" placeholder="Quantidade" aria-label="escolha quantos" aria-describedby="basic-addon1">
            `;
            itensdiv.appendChild(div);
        });
    } catch (error) {
        console.error('Error fetching items for order:', error);
    }
}

async function saveOrder() {
    const response = await fetch('/orders/saveOrder', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
    });
    if (response.ok) {
        getAllOrders();
    } else {
        console.error('Error saving order:', response.statusText);
    }
}

getAllOrders();

const addorderBtn = document.querySelector('#addItemBtn');
addorderBtn.addEventListener('click', () => {
    getItemsForOrder();
    saveOrder();
});