async function deleteItem(itemId) {
    try {
        const response = await fetch(`/menu/deleteitem/${itemId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        if (response.ok) {
            console.log('Item deleted successfully');
            getAllItems(); // Refresh the item list
        } else {
            console.error('Error deleting item:', response.statusText);
        }
    } catch (error) {
        console.error('Error deleting item:', error);
    }
}

async function getAllItems() {
    try {
        const response = await fetch('/menu/getitems', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const items = await response.json();
        console.log('Items fetched successfully:', items);

        const itemsContainer = document.querySelector('#itensContainer');
        console.log('Items container:', itemsContainer);
        itemsContainer.innerHTML = ''; // Clear existing items
        items.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'item';
            itemDiv.innerHTML = `<div class="item-card">
        <button class="remove-item" id="item${item.id}">×</button>
        <h3>${item.nome}</h3>
        <p>${item.descricao}</p>
        <p><strong>R$ ${item.preco.toFixed(2)}</strong></p>
      </div>

    </div>`;
            itemsContainer.appendChild(itemDiv);
            let deleteBtn = itemDiv.querySelector('#item' + item.id);
            deleteBtn.addEventListener('click', () => {
                deleteItem(item.id);
            });
        });
    } catch (error) {
        console.error('Error fetching items:', error);
    }
}

async function saveItem() {
    const name = document.querySelector('#item-name').value;
    const description = document.querySelector('#item-description').value;
    const price = parseFloat(document.querySelector('#item-price').value);

    if (!name || !description || isNaN(price)) {
        alert('Por favor, preencha todos os campos corretamente.');
        return;
    }

    try {
        const response = await fetch('/menu/additem', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nome: name, descricao: description, preco: price })
        });

        if (response.ok) {
            console.log('Item saved successfully');
            getAllItems(); // Refresh the item list
        } else {
            console.error('Error saving item:', response.statusText);
        }
    } catch (error) {
        console.error('Error saving item:', error);
    }
}

getAllItems();