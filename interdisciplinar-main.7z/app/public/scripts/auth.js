const loginBtn = document.querySelector('#loginBtn');

const usernameInput = document.querySelector('#username');
const passwordInput = document.querySelector('#password');

loginBtn.addEventListener('click', async () => {
    const response = await fetch('/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: usernameInput.value,
            password: passwordInput.value
        })
    });

    console.log(response.ok);

    if (response.ok) {
        // Login successful
        window.location.href = '/menu';
        sessionStorage.setItem('username',usernameInput.value);
    } else {
        // Login failed
        alert('Login failed. Please check your credentials and try again.');
    }

});