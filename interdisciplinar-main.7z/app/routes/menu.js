const path = require('path');
const express = require('express');

const pages = express.Router();

pages.get('/', (req,res) => { //cardápio
    const page = path.join(__dirname,"../public/views/menu.html");
    res.sendFile(page);
});

const { getItens, deleteItem, createItens } = require('../controllers/items.js');

pages.get('/getitems', getItens)
pages.delete('/deleteitem/:id', deleteItem)
pages.post('/additem', createItens)

module.exports = pages