const express = require("express");
const path = require("path");

const auth = express.Router();

auth.get('/',(req,res)=>{
    const page = path.join(__dirname,"../public/views/login.html");
    res.sendFile(page);
})

auth.get('/register',(req,res)=>{
    const page = path.join(__dirname,"../public/views/register.html");
    res.sendFile(page);
})

const {createConta, authConta} = require("../controllers/auth.js");

auth.post('/register',createConta);
auth.post('/login',authConta);

module.exports = auth;