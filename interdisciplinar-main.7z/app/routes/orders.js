const path = require('path');
const express = require('express');

const pages = express.Router();

pages.get('/',(req,res)=>{//pedidos
    const page = path.join(__dirname,'../public/views/orders.html');
    res.sendFile(page);
});

const {getAllOrders} = require('../controllers/orders');

pages.get('/getOrders', getAllOrders);

module.exports = pages