require('dotenv').config();
const {PrismaClient} = require('../generated/prisma');
const prisma = new PrismaClient();

async function createConta(req,res) {
    const { username, password } = req.body;

    console.log('Received registration data:', { username, password });

    try {
        const conta = await prisma.conta.create({
            data: {
                nome: username,
                senha: password
            }
        });
        res.status(201).json(conta);
    } catch (error) {
        console.error('Error creating conta:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

async function authConta(req, res) {
    const { username, password } = req.body;

    try {
        const conta = await prisma.conta.findUnique({
            where: {
                nome: username
            }
        });

        console.log(conta)

        if (conta && conta.senha === password) {
            res.status(200).json({ message: 'Login successful' });
        } else {
            res.status(401).json({ error: 'Invalid credentials' });
        }
    } catch (error) {
        console.error('Error authenticating conta:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

module.exports = { createConta, authConta };