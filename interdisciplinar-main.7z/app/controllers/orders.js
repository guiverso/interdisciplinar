const {PrismaClient} = require('../generated/prisma');

const prisma = new PrismaClient();

async function createOrder(req, res) {
    const { items, totalPrice, username } = req.body;

    try {
        const order = await prisma.pedidos.create({
            data: {
                items,
                totalPrice,
                user: {
                    connect: { username }
                }
            }
        });
        res.status(201).json(order);
    } catch (error) {
        console.error("Error creating order:", error);
        res.status(500).json({ error: "Internal server error" });
    }
}

async function getAllOrders(req,res) {
    try {
        const orders = await prisma.pedidos.findMany();
        res.status(200).json(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

module.exports = {
    createOrder,
    getAllOrders
};