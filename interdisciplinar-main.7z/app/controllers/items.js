const {PrismaClient} = require('../generated/prisma');
const prisma = new PrismaClient();

async function createItens(req,res) {
    const { nome, descricao, preco } = req.body;

    try {
        const item = await prisma.item.create({
            data: {
                nome,
                descricao,
                preco
            }
        });
        res.status(201).json(item);
    } catch (error) {
        console.error('Error creating item:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

async function getItens(req,res) {
    try {
        const itens = await prisma.item.findMany();
        res.status(200).json(itens);
    } catch (error) {
        console.error('Error fetching items:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

async function deleteItem(req,res) {
    const { id } = req.params;
    try {
        await prisma.item.delete({
            where: { id: Number(id) }
        });
        res.status(204).send();
    } catch (error) {
        console.error('Error deleting item:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

async function createtest(nome, desc, prec) {
    try {
        const item = await prisma.item.create({
            data: {
                nome,
                descricao: desc,
                preco: prec
            }
        });
        console.log('Item created:', item);
    } catch (error) {
        console.error('Error creating item:', error);
    }  
}

module.exports = { createItens, getItens, deleteItem };